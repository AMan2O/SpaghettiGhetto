﻿namespace SemesterProject
{
    public class Circle
    {
        public uint cx, cy, r;
        public Circle((int, int) dimensions, uint r)
        {
            this.cx = (uint)dimensions.Item1;
            this.cy = (uint)dimensions.Item2;
            this.r = r;
        }
    }


    public class Rectangle
    {
        public int x, y, width, height;
        public string color;
        public Rectangle((int, int) position, (int, int) dimensions)
        {
            this.x = position.Item1;
            this.y = position.Item2;
            this.width = dimensions.Item1;
            this.height = dimensions.Item2;
        }
    }

    public class Ellipse
    {
        public int cx, cy, rx, ry;
        public Ellipse((int, int) position, (int, int) dimensions)
        {
            this.cx = position.Item1;
            this.cy = position.Item2;
            this.rx = dimensions.Item1;
            this.ry = dimensions.Item2;
        }
    }
    public class SvgBuilder
    {
        private const string SVG_HEADER_TEMPLATE = "<svg width=\"{0}\" height=\"{1}\" xmlns=\"http://www.w3.org/2000/svg\">";
        private const string SVG_FOOTER = "</svg>";
        private const string RECT_TEMPLATE = "<rect x=\"{0}\" y=\"{1}\" width=\"{2}\" height=\"{3}\" style=\"fill:{4}\" />";
        private const string CIRCLE_TEMPLATE = "<circle cx=\"{0}\" cy=\"{1}\" r=\"{2}\" style=\"fill:{3}\" />";
        private const string ELLIPSE_TEMPLATE = "<ellipse cx=\"{0}\" cy=\"{1}\" rx=\"{2}\" ry=\"{3}\" style=\"fill:{4}\" />";

        private string Buffer;
        private uint Width;
        private uint Height;

        


        public static SvgBuilder New((uint, uint) dimensions)
        {
            var (width, height) = dimensions;

            return new()
            {
                Buffer = string.Empty,
                Width = width,
                Height = height,
            };
        }

        public string Build() =>
            string.Format(SVG_HEADER_TEMPLATE, Width, Height)
                + Buffer
                + SVG_FOOTER;

        
        public SvgBuilder AddShape(Rectangle rectangle, string hue) 
        {
            //Width = rectangle.width; Height = rectangle.height;
            Buffer += String.Format(RECT_TEMPLATE, rectangle.x, rectangle.y, rectangle.width, rectangle.height, hue);    
            return this;
        }
        public SvgBuilder AddShape(Circle circle, string hue)
        {
            Buffer += String.Format(CIRCLE_TEMPLATE, circle.cx, circle.cy, circle.r, hue);
            return this;
        }
        public SvgBuilder AddShape(Ellipse elipse, string hue)
        {
            Buffer += String.Format(ELLIPSE_TEMPLATE, elipse.cx, elipse.cy, elipse.rx, elipse.ry, hue);
            return this;
        }
    }
}
