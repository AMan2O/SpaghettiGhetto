﻿

using static SemesterProject.SvgBuilder;

namespace SemesterProject
{

    internal class Program
    {
        static void Main()
        {
            var svg = SvgBuilder.New((500, 500))
                .AddShape(new Circle((200, 100), 50), "#abc123")
                .AddShape(new Rectangle((12, 34), (300, 21)), "#aaaaaa")
                .AddShape(new Ellipse((300, 300), (20, 200)), "#000000")
                .Build();

            Console.Write("Absolute path to save SVG at: ");
            var path = Console.ReadLine() ?? "";

            using var fileWriter = FileWriter.FromAbsolutePath(path);
            fileWriter.WriteLine(svg);
        }
    }
}
