namespace SemesterProject.Tests
{
    public class TheSvgBuilder
    {
        [Test]
        public void BuildsSvgsWithTheCorrectSize()
        {
            var svg = SvgBuilder.New((123, 456)).Build();

            Assert.That(svg, Contains.Substring("width=\"123\""));
            Assert.That(svg, Contains.Substring("height=\"456\""));
        }

        [Test]
        public void AddsRectangles()
        {
            var svg = SvgBuilder.New((500, 500))
                .AddShape(new Rectangle((12, 34), (43, 21)), "#abc123")
                .Build();

            Assert.That(svg, Contains.Substring("x=\"12\""));
            Assert.That(svg, Contains.Substring("y=\"34\""));
            Assert.That(svg, Contains.Substring("width=\"43\""));
            Assert.That(svg, Contains.Substring("height=\"21\""));
            Assert.That(svg, Contains.Substring("fill:#abc123"));
        }

        [Test]
        public void AddsCircles()
        {
            var svg = SvgBuilder.New((500, 500))
                .AddShape(new Circle((12, 34), 50), "#abc123")
                .Build();

            Assert.That(svg, Contains.Substring("cx=\"12\""));
            Assert.That(svg, Contains.Substring("cy=\"34\""));
            Assert.That(svg, Contains.Substring("r=\"50\""));
            Assert.That(svg, Contains.Substring("fill:#abc123"));
        }
    }
}
